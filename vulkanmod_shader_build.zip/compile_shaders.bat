@echo off
REM ============================================================
REM VulkanMod Android — Compilar shaders GLSL -> SPIR-V
REM Requer: glslc.exe do Vulkan SDK
REM Uso: compile_shaders.bat <pasta_shaders_src> <pasta_output>
REM ============================================================

SET SRC=%1
SET OUT=%2
IF "%SRC%"=="" SET SRC=.\shaders_src
IF "%OUT%"=="" SET OUT=.\spv_out

WHERE glslc >nul 2>&1
IF ERRORLEVEL 1 (
    echo ERRO: glslc nao encontrado. Instalar Vulkan SDK.
    echo https://vulkan.lunarg.com/sdk/home
    exit /b 1
)

echo Compilador: glslc
echo Fonte: %SRC%
echo Output: %OUT%
echo.

SET OK=0
SET FAIL=0

CALL :COMPILE "gui"                     "gui.vsh"                                  "gui.fsh"
CALL :COMPILE "panorama"                "panorama.vsh"                             "panorama.fsh"
CALL :COMPILE "sky"                     "sky.vsh"                                  "sky.fsh"
CALL :COMPILE "stars"                   "stars.vsh"                                "stars.fsh"
CALL :COMPILE "text"                    "rendertype_text.vsh"                      "rendertype_text.fsh"
CALL :COMPILE "text_see_through"        "rendertype_text_see_through.vsh"          "rendertype_text_see_through.fsh"
CALL :COMPILE "text_intensity"          "rendertype_text_intensity.vsh"            "rendertype_text_intensity.fsh"
CALL :COMPILE "text_intensity_see_through" "rendertype_text_intensity_see_through.vsh" "rendertype_text_intensity_see_through.fsh"
CALL :COMPILE "text_background"         "rendertype_text_background.vsh"           "rendertype_text_background.fsh"
CALL :COMPILE "text_background_see_through" "rendertype_text_background_see_through.vsh" "rendertype_text_background_see_through.fsh"
CALL :COMPILE "opaque_particle"         "particle.vsh"                             "particle.fsh"
CALL :COMPILE "translucent_particle"    "particle.vsh"                             "particle.fsh"
CALL :COMPILE "lines"                   "rendertype_lines.vsh"                     "rendertype_lines.fsh"
CALL :COMPILE "line_strip"              "rendertype_lines.vsh"                     "rendertype_lines.fsh"
CALL :COMPILE "outline_cull"            "rendertype_outline.vsh"                   "rendertype_outline.fsh"
CALL :COMPILE "outline_no_cull"         "rendertype_outline.vsh"                   "rendertype_outline.fsh"
CALL :COMPILE "entity_solid"            "entity.vsh"                               "entity.fsh"
CALL :COMPILE "entity_cutout"           "entity.vsh"                               "entity.fsh"
CALL :COMPILE "entity_cutout_no_cull"   "entity.vsh"                               "entity.fsh"
CALL :COMPILE "entity_cutout_no_cull_z_offset" "entity.vsh"                        "entity.fsh"
CALL :COMPILE "entity_translucent"      "entity.vsh"                               "entity.fsh"
CALL :COMPILE "entity_translucent_emissive" "entity.vsh"                           "entity.fsh"
CALL :COMPILE "entity_no_outline"       "entity.vsh"                               "entity.fsh"
CALL :COMPILE "entity_shadow"           "rendertype_entity_shadow.vsh"             "rendertype_entity_shadow.fsh"
CALL :COMPILE "entity_decal"            "rendertype_entity_decal.vsh"              "rendertype_entity_decal.fsh"
CALL :COMPILE "entity_smooth_cutout"    "entity.vsh"                               "entity.fsh"
CALL :COMPILE "entity_solid_offset_forward" "entity.vsh"                           "entity.fsh"
CALL :COMPILE "armor_cutout_no_cull"    "entity.vsh"                               "entity.fsh"
CALL :COMPILE "armor_decal_cutout_no_cull" "entity.vsh"                            "entity.fsh"
CALL :COMPILE "armor_translucent"       "entity.vsh"                               "entity.fsh"
CALL :COMPILE "eyes"                    "entity.vsh"                               "entity.fsh"
CALL :COMPILE "solid"                   "terrain.vsh"                              "terrain.fsh"
CALL :COMPILE "cutout"                  "terrain.vsh"                              "terrain.fsh"
CALL :COMPILE "cutout_mipped"           "terrain.vsh"                              "terrain.fsh"
CALL :COMPILE "translucent"             "terrain.vsh"                              "terrain.fsh"
CALL :COMPILE "translucent_moving_block" "rendertype_translucent_moving_block.vsh" "rendertype_translucent_moving_block.fsh"
CALL :COMPILE "tripwire"                "terrain.vsh"                              "terrain.fsh"
CALL :COMPILE "water_mask"              "rendertype_water_mask.vsh"                "rendertype_water_mask.fsh"
CALL :COMPILE "crumbling"               "rendertype_crumbling.vsh"                 "rendertype_crumbling.fsh"
CALL :COMPILE "glint"                   "glint.vsh"                                "glint.fsh"
CALL :COMPILE "leash"                   "rendertype_leash.vsh"                     "rendertype_leash.fsh"
CALL :COMPILE "lightning"               "rendertype_lightning.vsh"                 "rendertype_lightning.fsh"
CALL :COMPILE "beacon_beam_opaque"      "rendertype_beacon_beam.vsh"               "rendertype_beacon_beam.fsh"
CALL :COMPILE "beacon_beam_translucent" "rendertype_beacon_beam.vsh"               "rendertype_beacon_beam.fsh"
CALL :COMPILE "end_portal"              "rendertype_end_portal.vsh"                "rendertype_end_portal.fsh"
CALL :COMPILE "end_sky"                 "sky.vsh"                                  "sky.fsh"
CALL :COMPILE "world_border"            "rendertype_world_border.vsh"              "rendertype_world_border.fsh"
CALL :COMPILE "energy_swirl"            "entity.vsh"                               "entity.fsh"
CALL :COMPILE "flat_clouds"             "rendertype_clouds.vsh"                    "rendertype_clouds.fsh"

echo.
echo ============================================
echo Sucesso: %OK%   Falhas: %FAIL%
echo ============================================
echo.
echo SPV gerados em: %OUT%\assets\vulkanmod\shaders\basic\
echo.
echo Copiar conteudo de %OUT%\assets\ para:
echo   src\main\resources\assets\vulkanmod\shaders\basic\
GOTO :EOF

:COMPILE
SET NAME=%~1
SET VSRC=%SRC%\core\%~2
SET FSRC=%SRC%\core\%~3
SET VOUT=%OUT%\assets\vulkanmod\shaders\basic\%NAME%\%NAME%.vert.spv
SET FOUT=%OUT%\assets\vulkanmod\shaders\basic\%NAME%\%NAME%.frag.spv

IF NOT EXIST "%OUT%\assets\vulkanmod\shaders\basic\%NAME%" (
    mkdir "%OUT%\assets\vulkanmod\shaders\basic\%NAME%"
)

glslc -fshader-stage=vert --target-env=vulkan1.1 -O "%VSRC%" -o "%VOUT%" 2>nul
IF ERRORLEVEL 1 (echo   FAIL: %NAME%.vert) ELSE (echo   OK:   %NAME%.vert && SET /A OK+=1)

glslc -fshader-stage=frag --target-env=vulkan1.1 -O "%FSRC%" -o "%FOUT%" 2>nul
IF ERRORLEVEL 1 (echo   FAIL: %NAME%.frag) ELSE (echo   OK:   %NAME%.frag && SET /A OK+=1)
GOTO :EOF
