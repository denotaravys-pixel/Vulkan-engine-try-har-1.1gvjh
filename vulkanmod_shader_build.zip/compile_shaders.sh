#!/bin/bash
# ============================================================
# VulkanMod Android — Compilar shaders GLSL → SPIR-V
# Requer: glslc (Vulkan SDK) ou glslangValidator
# Uso: ./compile_shaders.sh <pasta_com_shaders_src> <pasta_output>
# ============================================================

SRC="${1:-./shaders_src}"
OUT="${2:-./spv_out}"

# Detectar compilador
if command -v glslc &>/dev/null; then
    COMPILER="glslc"
elif command -v glslangValidator &>/dev/null; then
    COMPILER="glslangValidator"
else
    echo "❌ ERRO: glslc ou glslangValidator não encontrado."
    echo "   Instalar Vulkan SDK: https://vulkan.lunarg.com/sdk/home"
    exit 1
fi

echo "✅ Compilador: $COMPILER"
echo "📂 Fonte: $SRC"
echo "📂 Output: $OUT"
echo ""

OK=0
FAIL=0
SKIP=0

compile() {
    local src="$1"
    local stage="$2"   # vert ou frag
    local out_path="$3"
    local name="$4"

    mkdir -p "$(dirname "$out_path")"

    if [ "$COMPILER" = "glslc" ]; then
        glslc -fshader-stage="$stage" \
              --target-env=vulkan1.1 \
              -O \
              "$src" -o "$out_path" 2>/dev/null
    else
        local flag
        [ "$stage" = "vert" ] && flag="-S vert" || flag="-S frag"
        glslangValidator --target-env vulkan1.1 \
                         $flag \
                         "$src" -o "$out_path" 2>/dev/null
    fi

    if [ $? -eq 0 ] && [ -f "$out_path" ] && [ -s "$out_path" ]; then
        echo "  ✅ $name"
        ((OK++))
    else
        echo "  ❌ $name (falhou — shader pode precisar de includes)"
        ((FAIL++))
        rm -f "$out_path"
    fi
}

# ============================================================
# MAPEAMENTO: pipeline/X.vsh → core/Y.vsh → SPV output path
# Formato: "pipeline_name|src_vsh|src_fsh"
# ============================================================
declare -a MAPPINGS=(
    # --- GUI / Menu (críticos para arranque) ---
    "gui|core/gui.vsh|core/gui.fsh"
    "panorama|core/panorama.vsh|core/panorama.fsh"
    "sky|core/sky.vsh|core/sky.fsh"
    "stars|core/stars.vsh|core/stars.fsh"

    # --- Texto ---
    "text|core/rendertype_text.vsh|core/rendertype_text.fsh"
    "text_see_through|core/rendertype_text_see_through.vsh|core/rendertype_text_see_through.fsh"
    "text_intensity|core/rendertype_text_intensity.vsh|core/rendertype_text_intensity.fsh"
    "text_intensity_see_through|core/rendertype_text_intensity_see_through.vsh|core/rendertype_text_intensity_see_through.fsh"
    "text_background|core/rendertype_text_background.vsh|core/rendertype_text_background.fsh"
    "text_background_see_through|core/rendertype_text_background_see_through.vsh|core/rendertype_text_background_see_through.fsh"

    # --- Partículas ---
    "opaque_particle|core/particle.vsh|core/particle.fsh"
    "translucent_particle|core/particle.vsh|core/particle.fsh"

    # --- Linhas / Debug ---
    "lines|core/rendertype_lines.vsh|core/rendertype_lines.fsh"
    "line_strip|core/rendertype_lines.vsh|core/rendertype_lines.fsh"
    "outline_cull|core/rendertype_outline.vsh|core/rendertype_outline.fsh"
    "outline_no_cull|core/rendertype_outline.vsh|core/rendertype_outline.fsh"

    # --- Entidades ---
    "entity_solid|core/entity.vsh|core/entity.fsh"
    "entity_cutout|core/entity.vsh|core/entity.fsh"
    "entity_cutout_no_cull|core/entity.vsh|core/entity.fsh"
    "entity_cutout_no_cull_z_offset|core/entity.vsh|core/entity.fsh"
    "entity_translucent|core/entity.vsh|core/entity.fsh"
    "entity_translucent_emissive|core/entity.vsh|core/entity.fsh"
    "entity_no_outline|core/entity.vsh|core/entity.fsh"
    "entity_shadow|core/rendertype_entity_shadow.vsh|core/rendertype_entity_shadow.fsh"
    "entity_decal|core/rendertype_entity_decal.vsh|core/rendertype_entity_decal.fsh"
    "entity_smooth_cutout|core/entity.vsh|core/entity.fsh"
    "entity_solid_offset_forward|core/entity.vsh|core/entity.fsh"
    "armor_cutout_no_cull|core/entity.vsh|core/entity.fsh"
    "armor_decal_cutout_no_cull|core/entity.vsh|core/entity.fsh"
    "armor_translucent|core/entity.vsh|core/entity.fsh"
    "eyes|core/entity.vsh|core/entity.fsh"

    # --- Terreno / Blocos ---
    "solid|core/terrain.vsh|core/terrain.fsh"
    "cutout|core/terrain.vsh|core/terrain.fsh"
    "cutout_mipped|core/terrain.vsh|core/terrain.fsh"
    "translucent|core/terrain.vsh|core/terrain.fsh"
    "translucent_moving_block|core/rendertype_translucent_moving_block.vsh|core/rendertype_translucent_moving_block.fsh"
    "tripwire|core/terrain.vsh|core/terrain.fsh"
    "water_mask|core/rendertype_water_mask.vsh|core/rendertype_water_mask.fsh"
    "crumbling|core/rendertype_crumbling.vsh|core/rendertype_crumbling.fsh"

    # --- Efeitos / Ambiente ---
    "glint|core/glint.vsh|core/glint.fsh"
    "leash|core/rendertype_leash.vsh|core/rendertype_leash.fsh"
    "lightning|core/rendertype_lightning.vsh|core/rendertype_lightning.fsh"
    "beacon_beam_opaque|core/rendertype_beacon_beam.vsh|core/rendertype_beacon_beam.fsh"
    "beacon_beam_translucent|core/rendertype_beacon_beam.vsh|core/rendertype_beacon_beam.fsh"
    "end_portal|core/rendertype_end_portal.vsh|core/rendertype_end_portal.fsh"
    "end_sky|core/sky.vsh|core/sky.fsh"
    "world_border|core/rendertype_world_border.vsh|core/rendertype_world_border.fsh"
    "energy_swirl|core/entity.vsh|core/entity.fsh"
    "flat_clouds|core/rendertype_clouds.vsh|core/rendertype_clouds.fsh"

    # --- Item entity ---
    "rendertype_item_entity_translucent_cull|core/rendertype_item_entity_translucent_cull.vsh|core/rendertype_item_entity_translucent_cull.fsh"

    # --- Screenquad ---
    "screenquad|core/screenquad.vsh|"
)

echo "=== A COMPILAR SHADERS ==="
for entry in "${MAPPINGS[@]}"; do
    IFS='|' read -r pipeline_name src_vsh src_fsh <<< "$entry"

    # Vertex shader
    if [ -n "$src_vsh" ] && [ -f "$SRC/$src_vsh" ]; then
        out="$OUT/assets/vulkanmod/shaders/basic/$pipeline_name/${pipeline_name}.vert.spv"
        compile "$SRC/$src_vsh" "vert" "$out" "$pipeline_name.vert"
    elif [ -n "$src_vsh" ]; then
        echo "  ⚠️  $pipeline_name.vert — fonte não encontrada: $src_vsh"
        ((SKIP++))
    fi

    # Fragment shader
    if [ -n "$src_fsh" ] && [ -f "$SRC/$src_fsh" ]; then
        out="$OUT/assets/vulkanmod/shaders/basic/$pipeline_name/${pipeline_name}.frag.spv"
        compile "$SRC/$src_fsh" "frag" "$out" "$pipeline_name.frag"
    elif [ -n "$src_fsh" ]; then
        echo "  ⚠️  $pipeline_name.frag — fonte não encontrada: $src_fsh"
        ((SKIP++))
    fi
done

echo ""
echo "============================================"
echo "✅ Sucesso : $OK"
echo "❌ Falhas  : $FAIL"
echo "⚠️  Skipped : $SKIP"
echo "============================================"
echo ""
echo "📦 SPV gerados em: $OUT/assets/vulkanmod/shaders/basic/"
echo ""
echo "Próximo passo:"
echo "  Copiar o conteúdo de $OUT/assets/ para o repositório em:"
echo "  src/main/resources/assets/vulkanmod/shaders/basic/"
