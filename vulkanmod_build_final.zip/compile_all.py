#!/usr/bin/env python3
"""
VulkanMod Android - Compilar shaders pré-processados para SPIR-V
Uso: python3 compile_all.py
Requer: glslc no PATH (Vulkan SDK)
"""
import os, sys, subprocess, shutil

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PREPROC    = os.path.join(SCRIPT_DIR, "preprocessed")
OUT_BASE   = os.path.join(SCRIPT_DIR, "spv_out", "assets", "vulkanmod", "shaders", "basic")

MAPPINGS = {
    "gui":                              ("rendertype_gui",                       "rendertype_gui"),
    "gui_textured":                     ("rendertype_gui",                       "rendertype_gui"),
    "gui_text":                         ("rendertype_gui",                       "rendertype_gui"),
    "gui_text_highlight":               ("rendertype_gui_text_highlight",        "rendertype_gui_text_highlight"),
    "gui_invert":                       ("rendertype_gui_overlay",               "rendertype_gui_overlay"),
    "gui_nausea_overlay":               ("rendertype_gui_overlay",               "rendertype_gui_overlay"),
    "gui_opaque_textured_background":   ("rendertype_gui",                       "rendertype_gui"),
    "gui_textured_premultiplied_alpha":  ("rendertype_gui",                      "rendertype_gui"),
    "panorama":                         ("blit_screen",                          "blit_screen"),
    "mojang_logo":                      ("blit_screen",                          "blit_screen"),
    "crosshair":                        ("rendertype_gui",                       "rendertype_gui"),
    "vignette":                         ("rendertype_gui_overlay",               "rendertype_gui_overlay"),
    "text":                             ("rendertype_text",                      "rendertype_text"),
    "text_see_through":                 ("rendertype_text_see_through",          "rendertype_text_see_through"),
    "text_intensity":                   ("rendertype_text_intensity",            "rendertype_text_intensity"),
    "text_intensity_see_through":       ("rendertype_text_intensity_see_through","rendertype_text_intensity_see_through"),
    "text_background":                  ("rendertype_text_background",           "rendertype_text_background"),
    "text_background_see_through":      ("rendertype_text_background_see_through","rendertype_text_background_see_through"),
    "text_polygon_offset":              ("rendertype_text",                      "rendertype_text"),
    "sky":                              ("rendertype_solid",                     "rendertype_solid"),
    "stars":                            ("rendertype_solid",                     "rendertype_solid"),
    "celestial":                        ("rendertype_solid",                     "rendertype_solid"),
    "end_sky":                          ("rendertype_solid",                     "rendertype_solid"),
    "sunrise_sunset":                   ("rendertype_solid",                     "rendertype_solid"),
    "flat_clouds":                      ("rendertype_clouds",                    "rendertype_clouds"),
    "solid":                            ("rendertype_solid",                     "rendertype_solid"),
    "cutout":                           ("rendertype_cutout",                    "rendertype_cutout"),
    "cutout_mipped":                    ("rendertype_cutout_mipped",             "rendertype_cutout_mipped"),
    "translucent":                      ("rendertype_translucent",               "rendertype_translucent"),
    "translucent_moving_block":         ("rendertype_translucent_moving_block",  "rendertype_translucent_moving_block"),
    "tripwire":                         ("rendertype_tripwire",                  "rendertype_tripwire"),
    "water_mask":                       ("rendertype_water_mask",                "rendertype_water_mask"),
    "crumbling":                        ("rendertype_crumbling",                 "rendertype_crumbling"),
    "entity_solid":                     ("rendertype_entity_solid",              "rendertype_entity_solid"),
    "entity_cutout":                    ("rendertype_entity_cutout",             "rendertype_entity_cutout"),
    "entity_cutout_no_cull":            ("rendertype_entity_cutout_no_cull",     "rendertype_entity_cutout_no_cull"),
    "entity_cutout_no_cull_z_offset":   ("rendertype_entity_cutout_no_cull_z_offset","rendertype_entity_cutout_no_cull_z_offset"),
    "entity_translucent":               ("rendertype_entity_translucent",        "rendertype_entity_translucent"),
    "entity_translucent_emissive":      ("rendertype_entity_translucent_emissive","rendertype_entity_translucent_emissive"),
    "entity_no_outline":                ("rendertype_entity_no_outline",         "rendertype_entity_no_outline"),
    "entity_shadow":                    ("rendertype_entity_shadow",             "rendertype_entity_shadow"),
    "entity_decal":                     ("rendertype_entity_decal",              "rendertype_entity_decal"),
    "entity_smooth_cutout":             ("rendertype_entity_smooth_cutout",      "rendertype_entity_smooth_cutout"),
    "entity_solid_offset_forward":      ("rendertype_entity_solid",              "rendertype_entity_solid"),
    "eyes":                             ("rendertype_eyes",                      "rendertype_eyes"),
    "energy_swirl":                     ("rendertype_energy_swirl",              "rendertype_energy_swirl"),
    "breeze_wind":                      ("rendertype_breeze_wind",               "rendertype_breeze_wind"),
    "armor_cutout_no_cull":             ("rendertype_armor_cutout_no_cull",      "rendertype_armor_cutout_no_cull"),
    "armor_decal_cutout_no_cull":       ("rendertype_armor_cutout_no_cull",      "rendertype_armor_cutout_no_cull"),
    "armor_translucent":                ("rendertype_entity_translucent_cull",   "rendertype_entity_translucent_cull"),
    "glint":                            ("rendertype_glint",                     "rendertype_glint"),
    "leash":                            ("rendertype_leash",                     "rendertype_leash"),
    "lightning":                        ("rendertype_lightning",                 "rendertype_lightning"),
    "beacon_beam_opaque":               ("rendertype_beacon_beam",               "rendertype_beacon_beam"),
    "beacon_beam_translucent":          ("rendertype_beacon_beam",               "rendertype_beacon_beam"),
    "end_portal":                       ("rendertype_end_portal",                "rendertype_end_portal"),
    "end_gateway":                      ("rendertype_end_portal",                "rendertype_end_portal"),
    "world_border":                     ("rendertype_world_border",              "rendertype_world_border"),
    "secondary_block_outline":          ("rendertype_outline",                   "rendertype_outline"),
    "outline_cull":                     ("rendertype_outline",                   "rendertype_outline"),
    "outline_no_cull":                  ("rendertype_outline",                   "rendertype_outline"),
    "lines":                            ("rendertype_lines",                     "rendertype_lines"),
    "line_strip":                       ("rendertype_lines",                     "rendertype_lines"),
    "opaque_particle":                  ("particle",                             "particle"),
    "translucent_particle":             ("particle",                             "particle"),
    "block_screen_effect":              ("rendertype_entity_solid",              "rendertype_entity_solid"),
    "fire_screen_effect":               ("rendertype_entity_solid",              "rendertype_entity_solid"),
    "debug_filled_box":                 ("position_color",                       "position_color"),
    "debug_line_strip":                 ("position_color",                       "position_color"),
    "debug_quads":                      ("position_color",                       "position_color"),
    "debug_section_quads":              ("position_color",                       "position_color"),
    "debug_structure_quads":            ("position_color",                       "position_color"),
    "debug_triangle_fan":               ("position_color",                       "position_color"),
    "wireframe":                        ("rendertype_lines",                     "rendertype_lines"),
}

def compile_shader(src, stage, out):
    result = subprocess.run(
        ["glslc", f"-fshader-stage={stage}", "--target-env=vulkan1.1", "-O", src, "-o", out],
        capture_output=True, text=True
    )
    return result.returncode == 0, result.stderr

def main():
    if not shutil.which("glslc"):
        print("ERRO: glslc não encontrado.")
        print("Instalar Vulkan SDK: https://vulkan.lunarg.com/sdk/home")
        sys.exit(1)

    os.makedirs(OUT_BASE, exist_ok=True)
    ok = fail = 0
    failed_list = []

    print(f"A compilar {len(MAPPINGS) * 2} shaders...\n")

    for pipeline, (vname, fname) in MAPPINGS.items():
        out_dir = os.path.join(OUT_BASE, pipeline)
        os.makedirs(out_dir, exist_ok=True)

        for src_name, stage, ext in [(vname+".vsh","vert","vert.spv"), (fname+".fsh","frag","frag.spv")]:
            src = os.path.join(PREPROC, src_name)
            out = os.path.join(out_dir, f"{pipeline}.{ext}")
            if not os.path.exists(src):
                print(f"  ⚠  {pipeline}.{ext} — fonte não encontrada: {src_name}")
                fail += 1
                continue
            success, err = compile_shader(src, stage, out)
            if success:
                print(f"  ✅ {pipeline}.{ext}")
                ok += 1
            else:
                print(f"  ❌ {pipeline}.{ext} — {err.strip()[:80]}")
                failed_list.append(f"{pipeline}.{ext}")
                fail += 1

    print(f"\n{'='*50}")
    print(f"✅ Sucesso : {ok}")
    print(f"❌ Falhas  : {fail}")
    print(f"{'='*50}")
    print(f"\nSPV em: spv_out/assets/vulkanmod/shaders/basic/")
    print(f"\nCopiar para o repositório:")
    print(f"  src/main/resources/assets/vulkanmod/shaders/basic/")
    if failed_list:
        print(f"\nFalharam: {failed_list}")

if __name__ == "__main__":
    main()
